<?php

namespace App\Http\Livewire\StudyAbroad;

use Livewire\Component;

class StudyInUsa extends Component
{
    public function render()
    {
        return view('livewire.study-abroad.study-in-usa')->layout('layouts.page');
    }
}
