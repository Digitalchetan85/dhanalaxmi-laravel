<?php return array (
  'about-component' => 'App\\Http\\Livewire\\AboutComponent',
  'certifications.certifications' => 'App\\Http\\Livewire\\Certifications\\Certifications',
  'coaching.coaching' => 'App\\Http\\Livewire\\Coaching\\Coaching',
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'home.home-component' => 'App\\Http\\Livewire\\Home\\HomeComponent',
  'services.free-counselling' => 'App\\Http\\Livewire\\Services\\FreeCounselling',
  'study-abroad.study-in-usa' => 'App\\Http\\Livewire\\StudyAbroad\\StudyInUsa',
);