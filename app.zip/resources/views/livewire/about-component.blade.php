<div>
    <!-- /.header classic -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    <h1 class="page-title">About JDR Consultancy</h1>
                    <p class="page-description">Study abroad for better employment opportunities, a higher standard of living. Reach out to us for other opportunities for more details.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="page-breadcrumb">
        <!-- page breadcrumb -->
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- /.page breadcrumb -->
    <div class="content pdb0">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    <h2>About our consulting</h2>
                    <p class="lead">JDR Consultancy, one of the top study migration consultants, understand the challenges arising during study migration. Our primary goal is to assist you in scaling through these processes, such as assessment, documentation, and filing.</p>
                    <p>JDR Consultancy provides assistance to study in all top countries surf through the top-ranked schools and help you to pursue your dream.</p>
                    <p>We have expert professionals, who will guide from the beginning to the end process(from getting an offer letter to getting a visa and accommodation).</p>
                    <p>We have a global presence with a strategic network of own and associate offices in 25 locations across the world. We are planning to extend our services to over 20 offices by the year-end.</p>
                    <p>Get in touch with us today, so we can help you to realise your dream.</p>
                    <p class="text-default">Call:  +91 8919218102</p>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="image-block"><img src="{{asset('assets/images/about-us-fancy-img-2.png')}}" alt="" class="img-fluid"></div>
                </div>
            </div>
        </div>
        <div class="space-medium pdb0">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb mb20">
                            <div class="feature-content">
                                <h3 class="feature-title">Our Mision</h3>
                                <p>Our mission is to maximize our client’s chances of landing at their dream school, from loans to acquiring a Study visa. We want to be your bridge from your home country to your dream country. </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb">
                            <div class="feature-content">
                                <h3 class="feature-title">Our Vision</h3>
                                <p>Our vision is to provide all our clients with a convenient, trustworthy and professional study migration service with personalized guidance. Whether you have immediate or pressing goals or long-term dreams, we will work with you to fulfil them.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-medium">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                        <h3>Get Back Your 'Ooo' With Study Migration!</h3>
                        <br>
                        <h3>Our Values</h3>
                        <p>We are committed to following the organizational values: Transparency, Excellence, Fairness, Accountability, Integrity, and Commitment.</p>
                    </div>
                </div>
            </div>
        </div>
         <div class="space-medium pdb0">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb mb20">
                            <div class="feature-content">
                                <div class=""><img src="{{asset('assets/images/office-img-1.jpg')}}" alt="" class="img-fluid"></div>
                                <div class=""><img src="{{asset('assets/images/office-img-2.html')}}" alt="" class="img-fluid"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb">
                            <div class="feature-content">
                                <h3 class="feature-title">How do we help?</h3>
                                <p>Our experts help you choose the destination, school, and course, as well as aid you with your application, and other paperwork.</p>
                            <h3>We provide:</h3>
                            <ul class="listnone check-circle">
                            <li>Free Study Abroad Counselling</li>
                            <li>Course Advice</li>
                            <li>Personalized Guidance For Preparation</li>
                        </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-medium bg-light">
            <div class="container">
                <div class="row">
                    <div class="offset-xl-2 col-xl-8 offset-lg-2 col-lg-8 col-md-12 col-sm-12 col-12">
                        <div class="section-title text-center">
                            <!-- section title start-->
                            <h2>Why JDR Consultancy?</h2>
                            <p> Since our founding, our primary goal has been to provide immigration in all over country and universities. Our impact is speak louder than our word.</p>
                        </div>
                        <!-- /.section title start-->
                    </div>
                </div>
                <div class="counter-section pdb0">
                    <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="counter-block text-center">
                                <h2 class="counter-title text-default">500+</h2>
                                <p class="counter-text">Institutions</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="counter-block text-center">
                                <h2 class="counter-title text-secondary">5800+</h2>
                                <p class="counter-text"> Counselled</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="counter-block text-center">
                                <h2 class="counter-title text-warning">500+</h2>
                                <p class="counter-text">Received Visa</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="counter-block text-center">
                                <h2 class="counter-title text-default">30+</h2>
                                <p class="counter-text">Country</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-large">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb mb40">
                            <div class="feature-content">
                                <h3 class="feature-title">Our Services</h3>
                                <p> We offer Free Study Abroad Counselling, Course Advice, and Other services - Free visa filling, International accommodation, Flight Bookings and Forex Cards and International sim cards.</p>
                                <a href="services.html" class="btn btn-default">Services</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="feature-blurb">
                            <div class="feature-content">
                                <h3 class="feature-title">Partner Colleges</h3>
                                <p> We have collaborated with top schools around the world. Feel free to explore our comprehensive range of Universities and Education partners that we represent.</p>
                                <a href="#" class="btn btn-default">View partner Colleges</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-section bg-background" style="background-image:url('{{asset('assets/images/background-img.jpg')}}');">
            <div class="space-large">
                <div class="container">
                    <div class="row">
                        <div class="offset-xl-2 col-xl-8 offset-lg-2 col-lg-8 col-md-12 col-sm-12 col-12">
                            <div class="section-title text-center">
                                <!-- section title start-->
                                <h2 class="text-white">Working Together, We Can Help</h2>
                                <p>Doubting the positive effects of our teamwork because you’ve been burned before? By working together with the clients, we learn that wins and losses affect everyone on the team. When teams work together, they can discuss and share a variety of perspectives of a situation.</p>
                                <a href="#" class="btn btn-primary">Join Us</a>
                            </div>
                            <!-- /.section title start-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
