<div>
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                    <h1 class="page-title">Contact us</h1>
                    <p class="page-description">Get in touch with us today, so we can help you to realise your dream. Contact us saves your dream!
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="page-breadcrumb">
        <!-- page breadcrumb -->
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Contact us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- /.page breadcrumb -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-7 col-sm-12 col-12">
                    <div class="contact-form-head">
                        <h2 class="mb0">Leave a Message Here</h2>
                        <p>One of our Dhanalaxmi Overseas Consultants will connect with you ASAP.</p>
                    </div>
                    <div class="contact-form mt30">
                        <form method="post" action="#">
                            <div class="form-group">
                                <label for="name">Name <span class="required">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                            </div>
                            <div class="form-group">
                                <label for="mobileno">Mobile No <span class="required">*</span></label>
                                <input type="text" class="form-control" id="mobileno" name="mobileno" placeholder="Mobile No" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address <span class="required">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject">
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea class="form-control" id="message" name="message" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="offset-xl-1 col-xl-6 offset-lg-1 col-lg-5 col-md-5 col-sm-12 col-12">
                    <h2>Quick Contact</h2>
                    <p>We are pleased to discuss your qualifications and options under the various immigration programs and answer any questions or concerns you may have.</p>
                    <h4 class="mb0">Phone</h4>
                    <p>+91-9513838585</p>
                    <div class="row mb30">
                        <div class="col">
                            <h4 class="mb0">Email</h4>
                            <p>info@jdrconsultancy.com</p>
                        </div>
                    </div>
                    <div class="row mb20">
                        <div class="col mb10">
                            <h4 class="mb0">Inquire with us</h4>
                            <p>info@jdrconsultancy.com</p>
                        </div>
                        <div class="col mb10">
                            <h4 class="mb0">Send your feedback</h4>
                            <p>support@jdrconsultancy.com</p>
                        </div>
                    </div>
                    <div class="row mb20">
                        <div class="col mb10">
                            <h4 class="mb0">Work with us</h4>
                            <p>info@jdrconsultancy.com</p>
                        </div>
                        <div class="col mb10">
                            <h4 class="mb0">For Alliance with us</h4>
                            <p>info@jdrconsultancy.com</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <h4 class="mb0">Head Office</h4>
                            <p>3RD FLOOR, 707, NTI LAYOUT, 10 CROSS, 10TH MAIN, II PHASE, Sahakara Nagar Bengaluru Urban, Karnataka, 560092</p>
                            <a href="#" class="btn-link-primary">View our all office & locations</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.050822316971!2d77.63219841409055!3d13.032435617068359!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae176a04ba7645%3A0x2e6f9357af5e5de0!2sLogo%20Design%20Company%20Bangalore!5e0!3m2!1sen!2sin!4v1650910333017!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\dhanalaxmi-laravel\resources\views/livewire/contact-component.blade.php ENDPATH**/ ?>